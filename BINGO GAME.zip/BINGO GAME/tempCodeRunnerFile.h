printf("\nComputers boards1: \n");
    print_board(rows_comp1, dim, false);
    printf("\nComputers boards2: \n");
    print_board(rows_comp2, dim, false);
    printf("\nComputers boards3: \n");
    print_board(rows_comp3, dim, false);